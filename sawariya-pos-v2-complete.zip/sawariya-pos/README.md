# Sawariya POS
Fast restaurant POS prototype for Sawariya / Seth Shree Swad Bhandaar.

## Vercel
This is a static PWA. Upload the folder/repository to GitHub and import it into Vercel. No build command is required; Vercel serves `index.html`.

## APK
The app is PWA-ready and can be wrapped into an Android APK using a Trusted Web Activity/PWA wrapper or Capacitor after the Vercel URL is live. The current environment does not include the Android SDK, so a compiled APK cannot be produced here; the web/PWA source is ready for packaging.

## Current V1
- Direct order-punch screen
- Dine In / Takeaway / Quick Bill
- Full Sawariya menu and prices
- Search and category filtering
- Cart quantities
- Packing charge for takeaway
- KOT action/toast
- Cash / UPI / Card / Split payment UI
- Mobile bottom navigation
- PWA offline shell
